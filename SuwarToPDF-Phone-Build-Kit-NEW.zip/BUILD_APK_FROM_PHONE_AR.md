# صور إلى PDF — بناء APK من الهاتف

- ارفع ملف الحزمة `SuwarToPDF-Phone-Build-Kit.zip` إلى مستودع GitHub.
- الحزمة تتضمن المشروع داخل `SuwarToPDF-Android-Project.zip`.
- ملف سير العمل `build-apk.yml` موجود داخل الحزمة للنسخ إلى `.github/workflows/build-apk.yml`.
- شغّل GitHub Actions، ثم حمّل artifact `SuwarToPDF-APK` إذا نجح البناء.

لم يُبنَ APK مسبقًا؛ يجب تشغيل البناء في GitHub للتأكد من نجاحه.
